@echo off
echo 🚀 Launching SRM Content Bot Engine...
cd backend
python -m app.main
pause
