from .database import get_or_create_collection

def hybrid_retrieve(query_text, n_results=5):
    collection = get_or_create_collection()
    
    # Retrieve closest matching context semantics
    results = collection.query(
        query_texts=[query_text],
        n_results=n_results
    )
    
    # Flatten out context documents
    context_chunks = results.get("documents", [[]])[0]
    return " \n\n ".join(context_chunks)

def construct_anti_hallucination_prompt(query, context, user_name="Student"):
    # Allow for general greetings without triggering "I do not know"
    greetings = ["hi", "hello", "hey", "who are you", "what can you do"]
    is_greeting = any(greet in query.lower() for greet in greetings)
    
    if not context.strip():
        if is_greeting:
            return (
                f"User: {query}\n"
                f"Assistant: Hello {user_name}! I am your SRM Academic Assistant. I can help you with your course materials, "
                f"syllabi, and exam weightage found in my knowledge base. How can I help you today?"
            )
        return (
            f"User Question: {query}\n\n"
            f"System Note: No SRM documents matched this query. Inform the user politely that you don't have information on this specific topic in your records, but offer to help with other SRM academic queries."
        )
        
    prompt = (
        f"You are the SRM Academic Assistant. Your goal is to help {user_name} with information from SRM documents.\n\n"
        f"--- GROUNDING RULES ---\n"
        f"1. If the answer is in the CONTEXT below, use it to provide a detailed and helpful response.\n"
        f"2. If the user is just saying hello or asking who you are, respond warmly as the SRM Assistant.\n"
        f"3. If the question is about SRM academics but NOT in the context, say you don't have those specific records yet.\n"
        f"4. Do not invent course codes or dates.\n\n"
        f"--- CONTEXT ---\n{context}\n----------------\n\n"
        f"Question: {query}\n"
        f"Answer:"
    )
    return prompt
