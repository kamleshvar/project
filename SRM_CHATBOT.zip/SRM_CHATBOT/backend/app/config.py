import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Map to the existing Presence resources
PRESENCE_DIR = os.path.abspath(os.path.join(BASE_DIR, "../../../PRESENCE"))
LLAMA_SERVER_PATH = os.path.join(PRESENCE_DIR, r"llama-b9360-bin-win-cpu-x64\llama-server.exe")
MODEL_PATH = os.path.join(PRESENCE_DIR, r"google_gemma-3-1b-it-Q4_K_M.gguf")

DB_DIR = os.path.abspath(os.path.join(BASE_DIR, "../../chroma_db"))
DOCS_DIR = os.path.abspath(os.path.join(BASE_DIR, "../../srm_docs"))

EMBEDDING_MODEL = "BAAI/bge-base-en-v1.5"
