import os
import subprocess
import httpx
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from .config import LLAMA_SERVER_PATH, MODEL_PATH, BASE_DIR
from .ingest import initialize_srm_knowledge_base
from .search import hybrid_retrieve, construct_anti_hallucination_prompt

llama_proc = None
STATIC_DIR = os.path.join(os.path.dirname(BASE_DIR), "static")

def purge_ports():
    try:
        for port in ["8001", "8081"]: # Using 8081 for SRM Bot to avoid conflict with Presence if both run
            try:
                cmd = f"Get-NetTCPConnection -LocalPort {port} -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess"
                pids = subprocess.check_output(["powershell", "-Command", cmd], text=True).strip().split('\n')
                for pid in pids:
                    if pid.strip():
                        subprocess.run(f"taskkill /F /PID {pid.strip()}", shell=True, capture_output=True)
            except: pass
    except: pass

@asynccontextmanager
async def lifespan(app: FastAPI):
    global llama_proc
    # purge_ports() 
    
    print("🚀 Initializing SRM Knowledge Base...")
    initialize_srm_knowledge_base()
    
    print("🧠 Starting Local LLM Engine...")
    cmd = [
        LLAMA_SERVER_PATH, "-m", MODEL_PATH, "--port", "8081", 
        "-c", "4096", "--host", "127.0.0.1", "-t", "8", "-np", "1"
    ]
    llama_proc = subprocess.Popen(cmd)
    
    # Wait for LLM server to be ready
    for i in range(30):
        await asyncio.sleep(1)
        try:
            async with httpx.AsyncClient() as client:
                res = await client.get("http://127.0.0.1:8081/health", timeout=1.0)
                if res.status_code == 200:
                    print("✅ LLM Engine Ready.")
                    break
        except: pass
        if (i+1) % 5 == 0: print(f"LLM Engine warming... ({i+1}/30)")

    yield
    if llama_proc:
        print("🛑 Shutting down LLM Engine...")
        subprocess.run(f"taskkill /F /PID {llama_proc.pid}", shell=True, capture_output=True)

app = FastAPI(title="SRM Content Bot Engine", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Serve Static Files
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
async def get_index():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "SRM Content Bot API is running. Frontend not found at " + index_path}

class QueryRequest(BaseModel):
    prompt: str
    user_name: str = "Student"

@app.post("/api/chat")
async def chat_with_srm_docs(request: QueryRequest):
    try:
        # Step 1: Semantic retrieval
        context = hybrid_retrieve(request.prompt)
        
        # Step 2: Prompt engineering
        final_prompt = construct_anti_hallucination_prompt(request.prompt, context, request.user_name)
        
        # Step 3: LLM Inference
        async with httpx.AsyncClient() as client:
            payload = {
                "messages": [
                    {"role": "system", "content": "You are a helpful SRM Academic Assistant."},
                    {"role": "user", "content": final_prompt}
                ],
                "temperature": 0.1, # Keep it deterministic for RAG
                "max_tokens": 1000
            }
            response = await client.post("http://127.0.0.1:8081/v1/chat/completions", json=payload, timeout=120.0)
            llm_response = response.json()['choices'][0]['message']['content'].strip()
        
        return {
            "query": request.prompt,
            "response": llm_response,
            "context_retrieved": context if context else "None"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)
