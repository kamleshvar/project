import chromadb
from chromadb.utils import embedding_functions
import os
from .config import DB_DIR, EMBEDDING_MODEL

# Ensure persistent directory exists
os.makedirs(DB_DIR, exist_ok=True)

# Initialize Persistent Client
chroma_client = chromadb.PersistentClient(path=DB_DIR)

# Initialize Embedding Function (Shared across ingest and search)
embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL)

def get_or_create_collection(collection_name="srm_contents"):
    return chroma_client.get_or_create_collection(
        name=collection_name, 
        embedding_function=embedding_fn
    )
