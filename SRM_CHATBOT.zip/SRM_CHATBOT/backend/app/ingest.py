import os
import re
import httpx
from bs4 import BeautifulSoup
from .database import get_or_create_collection
from .config import DOCS_DIR

def chunk_text(text, chunk_size=800, overlap=100):
    raw_chunks = [p.strip() for p in text.split("\n\n") if p.strip()]
    if len(raw_chunks) < 2:
        raw_chunks = [p.strip() for p in text.split("\n") if p.strip()]
    
    chunks = []
    for c in raw_chunks:
        if len(c) > chunk_size:
            sub_chunks = re.split(r'(?<=[.!?]) +', c)
            temp = ""
            for sc in sub_chunks:
                if len(temp) + len(sc) < chunk_size:
                    temp += " " + sc
                else:
                    if temp: chunks.append(temp.strip())
                    temp = sc
            if temp: chunks.append(temp.strip())
        else:
            chunks.append(c)
    return chunks

def parse_pdf(file_path):
    try:
        from pypdf import PdfReader
        reader = PdfReader(file_path)
        text = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text
    except Exception as e:
        print(f"❌ Error parsing PDF {file_path}: {e}")
        return ""

async def scrape_srm_website(url):
    print(f"🌐 Scraping: {url}")
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    }
    try:
        async with httpx.AsyncClient(headers=headers, follow_redirects=True) as client:
            response = await client.get(url, timeout=30.0)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                # Remove script and style elements
                for script in soup(["script", "style"]):
                    script.decompose()
                
                # Get text
                text = soup.get_text(separator='\n')
                # Clean up whitespace
                lines = (line.strip() for line in text.splitlines())
                chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
                text = '\n'.join(chunk for chunk in chunks if chunk)
                return text
            else:
                print(f"❌ Failed to scrape {url}: Status {response.status_code}")
                return ""
    except Exception as e:
        print(f"❌ Error scraping {url}: {e}")
        return ""

def initialize_srm_knowledge_base():
    # This is a synchronous wrapper for the async version if needed
    import asyncio
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    
    if loop.is_running():
        # If already running (like in FastAPI), we need a different approach
        # But for startup it should be fine
        pass
    else:
        loop.run_until_complete(process_srm_knowledge_base())

async def process_srm_knowledge_base():
    collection = get_or_create_collection()
    
    # Check if we've already done a full initialization
    # In a real scenario, we'd check if specific sources are updated
    if collection.count() > 10: # Assuming some data already exists
         print("💡 SRM Knowledge Base already has data. Checking for updates...")

    print("🚀 Processing SRM Knowledge Payload...")
    
    # 1. Process Local Files
    if not os.path.exists(DOCS_DIR):
        os.makedirs(DOCS_DIR)

    doc_id_counter = collection.count()
    for filename in os.listdir(DOCS_DIR):
        file_path = os.path.join(DOCS_DIR, filename)
        content = ""
        
        # Simple skip logic: if source is already in metadata (ideally we'd query)
        # For now, let's just index new files
        
        if filename.endswith(".txt"):
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
        elif filename.endswith(".pdf"):
            content = parse_pdf(file_path)
        
        if content:
            chunks = chunk_text(content)
            for i, chunk in enumerate(chunks):
                doc_id_counter += 1
                collection.add(
                    documents=[chunk],
                    metadatas=[{"source": filename, "type": "local", "chunk_index": i}],
                    ids=[f"srm_doc_{doc_id_counter}"]
                )
            print(f"✅ Indexed Local: {filename}")

    # 2. Process Web Info
    srm_urls = [
        "https://www.srmist.edu.in/about-us/",
        "https://www.srmist.edu.in/academics/"
    ]
    
    for url in srm_urls:
        web_content = await scrape_srm_website(url)
        if web_content:
            chunks = chunk_text(web_content)
            for i, chunk in enumerate(chunks):
                doc_id_counter += 1
                collection.add(
                    documents=[chunk],
                    metadatas=[{"source": url, "type": "web", "chunk_index": i}],
                    ids=[f"srm_web_{doc_id_counter}"]
                )
            print(f"✅ Indexed Web: {url} ({len(chunks)} chunks)")

    print(f"✅ Final Knowledge Base Size: {collection.count()} chunks.")
