const chatWindow = document.getElementById("chat-window");
const userInput = document.getElementById("user-input");
const sendBtn = document.getElementById("send-btn");
const connBadge = document.getElementById("conn-badge");
const connDot = document.getElementById("conn-dot");
const connText = document.getElementById("conn-text");

const knowledgeBase = [
  // ===== GENERAL =====
  {
    keywords: ["what is srmist known for", "what is srm known for", "flagship", "about srm", "tell me about srm"],
    answer: "SRM Institute of Science and Technology (SRMIST), established in 1985, is one of India's premier private universities. It is known for its world-class engineering, medicine, and management programs. The university consistently ranks among the top private universities in India with NAAC A++ accreditation. SRMIST has a sprawling 250+ acre campus in Kattankulathur, Chennai, with 15+ colleges, 50+ programs, and 52,000+ students."
  },
  {
    keywords: ["government or private", "private university", "deemed", "deemed university"],
    answer: "SRMIST is a private deemed university under Section 3 of the UGC Act. It is NOT a government university. It was established in 1985 by the SRM Group and has grown to become one of India's leading private institutions."
  },
  {
    keywords: ["ranking", "nirf", "rank"],
    answer: "SRMIST holds strong NIRF 2024 rankings: University #12, Engineering #13, Dental #7, Architecture #11, Pharmacy #11, Medical #18, Overall #21, and Research #24 nationally. It also holds NAAC A++ grade and ranks 2nd among private universities in the Nature Index."
  },
  {
    keywords: ["campuses", "how many campuses"],
    answer: "SRMIST has 6 campuses across India: Kattankulathur (Chennai - Main Campus), Ramapuram (Chennai), Vadapalani (Chennai), Tiruchirappalli, Delhi-NCR, and Baburayanpettai (Chengalpattu). It also has sister universities in Andhra Pradesh (SRM AP), Haryana, and Sikkim."
  },
  {
    keywords: ["naac", "accreditation", "accredited"],
    answer: "Yes, SRMIST is NAAC accredited with an A++ grade — the highest possible rating. It is also accredited by NBA, ICAR, and recognized by UGC. SRMIST features in NIRF, QS World Rankings, THE Rankings, and ARIIA rankings."
  },
  {
    keywords: ["established", "founded", "founded year", "started"],
    answer: "SRM Institute of Science and Technology was established in 1985 by the SRM Group of Educational Institutions. It was initially founded as SRM Engineering College and later granted deemed university status."
  },

  // ===== ADMISSIONS =====
  {
    keywords: ["eligibility", "b.tech eligibility", "btech eligibility", "criteria"],
    answer: "For B.Tech admissions at SRMIST: Candidates must have passed 10+2 with Physics, Chemistry, and Mathematics with minimum 50% marks (45% for reserved categories). Admission is through SRMJEEE (UG) or JEE Main score. For M.Tech: Bachelor's degree in relevant field with minimum 50% marks through SRMJEEE (PG). For MBA: Graduation with 50% marks through SRM PGDM-X or CAT/MAT/XAT scores."
  },
  {
    keywords: ["srmjeee", "how to apply", "application"],
    answer: "To apply for SRMJEEE 2026: Visit applications.srmist.edu.in, register with your email and phone, fill the application form with personal and academic details, upload required documents (photo, signature, marksheets), pay the application fee (₹1200 for UG), and book your exam slot. The exam is conducted in multiple phases from January to April."
  },
  {
    keywords: ["last date", "deadline", "deadline for admissions"],
    answer: "For admissions 2026-2027: SRMJEEE (UG) Phase I is underway. The last date for Phase I applications is typically in March/April 2026. Phase II applications extend till May/June 2026. International admissions have rolling deadlines. We recommend applying early as seats fill quickly."
  },
  {
    keywords: ["direct admission", "management quota", "direct"],
    answer: "SRMIST does offer direct/management quota admissions for certain programs subject to eligibility criteria and seat availability. However, the primary mode of admission is through SRMJEEE scores. For management quota, you need to meet the minimum eligibility of 50% in 10+2. Contact the admissions office at +91 44 27417000 for details."
  },
  {
    keywords: ["documents", "documents needed", "required documents"],
    answer: "Documents required for SRMIST admission: 1) 10th Marksheet & Certificate, 2) 12th Marksheet & Certificate (if passed), 3) SRMJEEE Admit Card & Scorecard, 4) Transfer Certificate (TC), 5) Migration Certificate, 6) Conduct Certificate, 7) Passport-size photographs, 8) Medical Fitness Certificate, 9) Category Certificate (if applicable), 10) Passport (for NRI/PIO/OCI candidates)."
  },
  {
    keywords: ["age limit", "age"],
    answer: "There is no specific age limit for SRMIST admissions. Candidates who have passed 10+2 or equivalent are eligible regardless of age. For international students, minimum age requirements may apply based on the program."
  },

  // ===== COURSES =====
  {
    keywords: ["engineering branches", "b.tech branches", "btech branches", "engineering courses"],
    answer: "SRMIST offers B.Tech in: Computer Science & Engineering (CSE), CSE with specializations in AI, ML, Cyber Security, Data Science, Cloud Computing; Electronics & Communication Engineering (ECE), Electrical & Electronics Engineering (EEE), Mechanical Engineering, Civil Engineering, Aerospace Engineering, Automobile Engineering, Chemical Engineering, Biotechnology, Biomedical Engineering, Robotics & Automation, and Information Technology. The CSE department is the most sought-after."
  },
  {
    keywords: ["mbbs", "medicine", "medical"],
    answer: "Yes, SRMIST offers MBBS through SRM Medical College Hospital & Research Centre. The course is 5.5 years including 1 year internship. Admission is through NEET UG score. The medical college has 250+ beds, advanced facilities, and is recognized by NMC. Fees are approximately ₹20-25 lakhs per year."
  },
  {
    keywords: ["mba specialization", "mba specializations", "management"],
    answer: "SRM's Faculty of Management offers MBA with specializations in: Marketing, Finance, Human Resources, Operations, Business Analytics, Digital Marketing, International Business, and Entrepreneurship. The program is 2 years with dual specialization option. SRM also offers PGDM-Executive and MMS programs."
  },
  {
    keywords: ["phd", "doctorate", "ph.d", "doctoral"],
    answer: "Yes, SRMIST offers Ph.D programs across all disciplines including Engineering, Science & Humanities, Management, Law, Medicine, and more. Duration is 3-5 years. Eligibility: Master's degree with minimum 55% marks. SRMIST has 900+ Ph.D scholars currently enrolled with 47000+ publications and 920+ patents."
  },
  {
    keywords: ["law courses", "law", "b.a.ll.b", "ll.b"],
    answer: "SRM School of Law offers: BA LLB (Hons) - 5 years integrated program, B.Com LLB (Hons) - 5 years, and LLM - 1 year program. Specializations include Constitutional Law, Corporate Law, Criminal Law, and International Law. The school has moot court facilities and collaborations with leading law firms."
  },
  {
    keywords: ["b.sc", "b.sc programs", "science programs"],
    answer: "Yes, SRM College of Science and Humanities offers B.Sc programs in: Physics, Chemistry, Mathematics, Computer Science, Biotechnology, Microbiology, Biochemistry, Nutrition & Dietetics, Visual Communication, Psychology, Economics, and more. All programs include hands-on lab work and research projects."
  },

  // ===== PLACEMENTS =====
  {
    keywords: ["which companies visit", "companies", "recruiters", "top recruiters"],
    answer: "980+ companies visit SRMIST for campus recruitment annually. Top recruiters include: Amazon, Microsoft, Google, Apple, Intel, IBM, TCS, Infosys, Wipro, Accenture, Deloitte, KPMG, EY, JP Morgan, Goldman Sachs, Barclays, Cisco, Oracle, Adobe, Uber, Ola, BYJU'S, Zomato, Flipkart, and many more."
  },
  {
    keywords: ["highest package", "highest salary", "highest ctc"],
    answer: "The highest placement package at SRMIST for 2023-24 was 52 LPA (domestic). The highest international package went up to ₹1.2 Crores. 2232+ high-paying offers (10+ LPA) were made. Top companies offering high packages include Amazon (up to 45 LPA), Microsoft (up to 40 LPA), and Google (up to 50 LPA)."
  },
  {
    keywords: ["average package", "average ctc", "average salary"],
    answer: "The average placement package at SRMIST for 2023-24 was 7.19 LPA. For CSE students, the average was higher at approximately 9-12 LPA. The median package across all branches was 6.5 LPA. These figures are for the Kattankulathur main campus."
  },
  {
    keywords: ["100% placement", "guaranteed placement", "placement guarantee"],
    answer: "SRMIST does NOT guarantee 100% placement. However, the Career Centre provides training, internships, and placement assistance to all eligible students. In 2023-24, 5546+ offers were made for eligible students. Placement is dependent on academic performance, skills, and market conditions."
  },
  {
    keywords: ["placement season", "when does placement", "placement time"],
    answer: "The placement season at SRMIST typically starts in August/September each year and continues till April/May. Pre-placement talks begin in July-August. The peak season is September to December. Major recruiters conduct campus drives from August onwards. Internship placements happen from January to March."
  },
  {
    keywords: ["internships", "internship"],
    answer: "Yes, SRMIST has a strong internship program managed by the Career Centre. Students undergo internships during summer/winter breaks (2-3 months). Many companies offer Pre-Placement Offers (PPOs) based on internship performance. Internship support includes training in resume building, interview skills, and industry connect."
  },

  // ===== CAMPUS LIFE =====
  {
    keywords: ["hostel facilities", "hostel", "accommodation"],
    answer: "SRMIST provides separate hostels for boys and girls with 15,000+ seats. Room types include Single, Double, Triple, and Dormitory options. Each hostel has Wi-Fi, 24/7 security, study rooms, recreation rooms, and medical facilities. Girls hostel has additional security measures. Hostel fee ranges from ₹60,000 to ₹1,20,000 per year depending on room type and AC/non-AC."
  },
  {
    keywords: ["clubs", "activities", "student clubs", "extracurricular"],
    answer: "SRMIST has 100+ student clubs across categories: Tech (coding, robotics, AI), Cultural (music, dance, drama, photography), Literary (debate, writing, quiz), Sports (cricket, football, basketball, tennis, athletics), Social (NSS, Rotaract, environment), and Entrepreneurship (E-cell, IIC). Milan is the annual national-level cultural festival."
  },
  {
    keywords: ["gym", "fitness", "sports facilities", "sports"],
    answer: "Yes, SRMIST has excellent sports and fitness facilities: a modern gymnasium, Olympic-size swimming pool, cricket ground, football field, basketball courts, tennis courts, badminton courts, volleyball courts, indoor sports complex, and athletics track. Professional coaches are available. Sports scholarships are awarded to talented athletes."
  },
  {
    keywords: ["milan", "cultural fest", "festival"],
    answer: "Milan is SRMIST's annual national-level cultural festival, typically held in February/March. It features competitions in dance, music, drama, fashion show, literary events, and art exhibitions. Students from 200+ colleges participate. Milan 2026 saw performances from renowned artists and prize money of ₹50+ lakhs."
  },
  {
    keywords: ["campus safety", "safe", "security"],
    answer: "Yes, SRMIST campus is very safe with 24/7 CCTV surveillance, security personnel at all entry points, biometric access for hostels, women's grievance redressal committee, anti-ragging committee, 24/7 helpline numbers, campus patrolling, and a dedicated security control room. The campus has been declared a ragging-free zone."
  },
  {
    keywords: ["transport", "bus", "commute"],
    answer: "SRMIST provides a comprehensive transport facility with 200+ buses operating from various parts of Chennai city to the Kattankulathur campus. Bus routes cover Tambaram, Guindy, T Nagar, Adyar, OMR, Porur, and other major areas. The nearest railway station is Paranur (1 km) and the nearest airport is Chennai International (40 km)."
  },

  // ===== FEES & SCHOLARSHIPS =====
  {
    keywords: ["b.tech fee", "btech fee", "b.tech fees", "cse fee"],
    answer: "B.Tech fees at SRMIST vary by specialization: CSE - ₹2,50,000/year, ECE - ₹2,30,000/year, Mechanical - ₹2,00,000/year, Civil - ₹1,80,000/year. Additional one-time fees include admission fee (₹10,000), library fee (₹5,000), and lab fee (₹5,000). Hostel and mess extra (₹60,000-1,20,000/year)."
  },
  {
    keywords: ["scholarship", "scholarships"],
    answer: "SRMIST offers generous scholarships up to 100% tuition fee waiver: 1) Merit-based: Top 1% SRMJEEE rankers get 100% waiver, next 4% get 50% waiver, 2) Sports scholarships for national/international athletes, 3) Need-based scholarships for economically weaker students, 4) Sibling scholarship (10% off for second sibling), 5) Alumni scholarship (15% off for children of alumni). ₹50+ Crores disbursed annually."
  },
  {
    keywords: ["scholarship apply", "how to apply scholarship", "scholarship application"],
    answer: "To apply for SRMIST scholarships: Check the scholarship section on the SRMIST website, download the scholarship application form, fill in academic and personal details, attach supporting documents (income certificate, marksheets, sports certificates if applicable), and submit to the scholarship committee before the deadline. Scholarships are renewed yearly based on academic performance (minimum 8 CGPA)."
  },
  {
    keywords: ["hostel fee", "hostel fees", "accommodation fee"],
    answer: "SRMIST hostel fees for 2024-25: Non-AC Single - ₹1,00,000/year, Non-AC Double - ₹75,000/year, Non-AC Triple - ₹60,000/year, AC Single - ₹1,50,000/year, AC Double - ₹1,20,000/year, AC Triple - ₹90,000/year. Mess fee is separate at ₹4,000-6,000/month. Caution deposit (refundable): ₹10,000."
  },
  {
    keywords: ["installment", "payment plan", "installment option"],
    answer: "Yes, SRMIST allows fee payment in installments. For B.Tech: Option 1 - Full payment at start of year (5% discount), Option 2 - 2 installments (50% each at start of each semester), Option 3 - 4 installments (25% each per quarter with minimal interest). Contact the finance office for custom payment plans."
  },
  {
    keywords: ["mba fee", "mba fees", "mba fee structure"],
    answer: "The MBA program at SRM Faculty of Management costs approximately ₹4,50,000 per year (total ₹9,00,000 for 2 years). The PGDM-Executive program fee is ₹3,50,000 per year. Additional costs include application fee (₹1,200), registration fee (₹5,000), and study material (₹10,000). EMI options available through partner banks."
  },

  // ===== RESEARCH =====
  {
    keywords: ["research facilities", "research labs", "laboratory facilities"],
    answer: "SRMIST has world-class central research facilities: NRC (Nanotechnology Research Center), REACH (Research in Energy, Environment & Chemistry), HPCC (High-Performance Computing Center), IIISM (Institute of Integrative Medicine), CACR (Centre for Advanced Computing Research), SCIF (Sophisticated Central Instrumentation Facility), Medical Research Center, Center for Statistics, Earthquake Research Cell, and SRM DBT Platform for bioinformatics."
  },
  {
    keywords: ["phd apply", "how to apply for phd", "phd admission"],
    answer: "To apply for PhD at SRMIST: Visit the Research section on the SRMIST website, check the notification for PhD admissions (usually June and December cycles), submit an online application with research proposal, appear for the entrance exam and interview conducted by the Research Council, and register after selection. Eligibility: Master's degree with 55% marks. Duration: 3-5 years."
  },
  {
    keywords: ["research areas", "research focus", "thrust areas"],
    answer: "SRMIST's key research thrust areas include: Nanotechnology & Materials Science, Artificial Intelligence & Machine Learning, Renewable Energy & Environment, Biomedical Engineering & Healthcare, Cybersecurity & Blockchain, Aerospace Engineering, Drug Discovery & Pharmacology, Structural Engineering, Water & Wastewater Treatment, and Social Sciences & Public Policy."
  },
  {
    keywords: ["industry collaboration", "collaborations", "industry connect"],
    answer: "SRMIST has 300+ MoUs with industry partners including IBM, Microsoft, Amazon, Intel, Bosch, Siemens, Tata, and DRDO. These collaborations facilitate joint research, funded projects, internships, guest lectures, lab setups, and curriculum development. The Innovation & Incubation Center supports student startups with funding up to ₹25 lakhs."
  },
  {
    keywords: ["patents", "how many patents"],
    answer: "SRMIST has filed 920+ patents as of 2024, making it one of the top patent-filing universities in India. The patents span across engineering, healthcare, nanotechnology, and renewable energy domains. Over 200 patents have been granted. SRMIST has a dedicated Patent Cell to assist faculty and students with patent filing."
  },
  {
    keywords: ["research funding", "funded projects", "funding amount"],
    answer: "SRMIST has received 250+ Crores in external research funding from agencies like DST, DBT, DRDO, ISRO, CSIR, ICAR, AICTE, and UGC. Currently, 544+ externally funded research projects are active. Major funded projects include solar energy technology (₹1 Crore licensing agreement), defense research collaborations, and biomedical innovations."
  },

  // ===== INTERNATIONAL =====
  {
    keywords: ["international students apply", "international admission", "foreign students"],
    answer: "International students can apply to SRMIST through the dedicated international admissions portal at intlapplications.srmist.edu.in. Requirements: Valid passport, equivalency certificate from Association of Indian Universities (AIU), English proficiency (IELTS 6.0/TOEFL 80+), academic transcripts, and student visa. SRMIST has 500+ international students from 85+ countries."
  },
  {
    keywords: ["semester abroad", "sap", "study abroad"],
    answer: "The Semester Abroad Program (SAP) at SRMIST allows students to spend 1-2 semesters at partner universities including MIT (USA), Carnegie Mellon (USA), UC Davis (USA), University of Warwick (UK), University of Western Australia, and many more. Over 200 students are sponsored annually. Credits earned abroad are transferred back to SRMIST."
  },
  {
    keywords: ["partner universities", "twinning", "collaboration universities"],
    answer: "SRMIST has 300+ MoUs with top global universities including: MIT (USA), Carnegie Mellon University (USA), University of California Davis (USA), University of Waterloo (Canada), University of Warwick (UK), University of Leeds (UK), University of Queensland (Australia), TU Munich (Germany), National University of Singapore, and many more."
  },
  {
    keywords: ["twinning program", "transfer program", "2+2"],
    answer: "SRMIST offers Twinning/Transfer programs (2+2 and 3+1 models) where students study 2-3 years at SRMIST and complete the remaining years at a partner university abroad. Degrees are awarded by both institutions. Popular destinations: USA, UK, Canada, Australia, Germany, and Singapore. Programs available for Engineering, Management, and Science disciplines."
  },
  {
    keywords: ["international scholarship", "international student scholarship"],
    answer: "Yes, international students can avail scholarships at SRMIST: SAARC country students get 25% tuition waiver, Non-SAARC developing countries get 15% waiver, Merit-based scholarships based on previous academic performance (up to 50%), and sports scholarships for international athletes. The International Relations Office provides assistance with all scholarship applications."
  },
  {
    keywords: ["visa", "visa process", "student visa"],
    answer: "For international students: SRMIST provides full visa support including the Confirmation of Admission letter required for visa application, FRRO registration assistance, and guidance on the Student Visa (S category) process. The International Relations Office helps with document verification, visa interview prep, and post-arrival registration. Processing time is typically 4-6 weeks."
  },
];

function findAnswer(query) {
  const q = query.toLowerCase().trim();
  for (const entry of knowledgeBase) {
    for (const kw of entry.keywords) {
      if (q.includes(kw)) return entry.answer;
    }
  }
  for (const entry of knowledgeBase) {
    for (const kw of entry.keywords) {
      const parts = kw.split(" ");
      let matchCount = 0;
      for (const part of parts) {
        if (q.includes(part) && part.length > 3) matchCount++;
      }
      if (matchCount >= Math.ceil(parts.filter(p => p.length > 3).length / 2)) {
        return entry.answer;
      }
    }
  }
  return null;
}

const topicIcons = {
  general: "fa-home",
  admissions: "fa-pen",
  courses: "fa-book",
  placements: "fa-briefcase",
  campus: "fa-building",
  fees: "fa-rupee-sign",
  research: "fa-flask",
  international: "fa-globe",
};

const topicData = {
  general: {
    label: "General Info",
    icon: "fa-home",
    info: "SRM Institute of Science and Technology (SRMIST) is one of India's premier private universities, established in 1985. With a sprawling 250+ acre campus in Kattankulathur, Chennai, SRMIST offers world-class education across engineering, medicine, management, law, and more. The university is NAAC A++ accredited and consistently ranks among the top private universities in India.",
    stats: [
      { value: "1985", label: "Established" },
      { value: "250+", label: "Acres" },
      { value: "52000+", label: "Students" },
      { value: "12th", label: "NIRF Univ" },
    ],
    hot: [
      "What is SRMIST known for?",
      "Is SRM a government or private university?",
      "What is the ranking of SRMIST?",
      "How many campuses does SRM have?",
      "Is SRMIST accredited by NAAC?",
      "When was SRM established?",
    ],
  },
  admissions: {
    label: "Admissions",
    icon: "fa-pen",
    info: "Admissions to SRMIST for the academic year 2026-2027 are now open! SRMIST offers admissions through SRMJEEE (UG & PG), JEE Main, and other national-level entrance exams. The university also accepts direct admissions for various programs. International students can apply through the dedicated international admissions portal.",
    stats: [
      { value: "2026", label: "Academic Year" },
      { value: "50+", label: "Programs" },
      { value: "10000+", label: "Seats" },
      { value: "100+", label: "Countries" },
    ],
    hot: [
      "What are the eligibility criteria for B.Tech?",
      "How to apply for SRMJEEE 2026?",
      "What is the last date for admissions?",
      "Can I get direct admission at SRM?",
      "What documents are needed for admission?",
      "Is there an age limit for SRM admissions?",
    ],
  },
  courses: {
    label: "Courses & Departments",
    icon: "fa-book",
    info: "SRMIST offers a diverse range of 50+ undergraduate, postgraduate, and doctoral programs across 15+ colleges and departments. From Engineering (CSE, ECE, Mechanical, Civil) to Medicine, Law, Management, Architecture, and Liberal Arts — SRMIST has something for every career aspiration. The curriculum is regularly updated to meet industry standards.",
    stats: [
      { value: "15+", label: "Colleges" },
      { value: "50+", label: "Programs" },
      { value: "200+", label: "Departments" },
      { value: "4.5L+", label: "Alumni" },
    ],
    hot: [
      "Which engineering branches are available?",
      "Does SRM offer MBBS?",
      "What are the specializations in MBA?",
      "Are there PhD programs at SRM?",
      "What courses are available in law?",
      "Does SRM have a B.Sc program?",
    ],
  },
  placements: {
    label: "Placements",
    icon: "fa-briefcase",
    info: "SRMIST has an outstanding placement record with 980+ companies visiting the campus in 2023-24. Top recruiters include Amazon, Microsoft, Google, TCS, Infosys, and more. The dedicated Career Centre provides training, internships, and placement assistance to all students. The highest package stood at 52 LPA.",
    stats: [
      { value: "980+", label: "Companies" },
      { value: "5546+", label: "Offers" },
      { value: "52 LPA", label: "Highest CTC" },
      { value: "7.19 LPA", label: "Avg CTC" },
    ],
    hot: [
      "Which companies visit SRM for placements?",
      "What is the highest package at SRM?",
      "What is the average package for CSE?",
      "Does SRM guarantee 100% placement?",
      "When does placement season start?",
      "Are there internships during the course?",
    ],
  },
  campus: {
    label: "Campus Life",
    icon: "fa-building",
    info: "Life at SRMIST is vibrant and enriching! The green campus features modern hostels, world-class sports facilities, a central library with 1L+ books, and numerous student clubs for music, dance, drama, tech, and entrepreneurship. Annual festivals like Milan and cultural events keep the campus buzzing all year round.",
    stats: [
      { value: "250+", label: "Green Acres" },
      { value: "100+", label: "Student Clubs" },
      { value: "20+", label: "Sports" },
      { value: "15000+", label: "Hostel Seats" },
    ],
    hot: [
      "What are the hostel facilities at SRM?",
      "What clubs and activities are available?",
      "Is there a gym on campus?",
      "What is Milan festival?",
      "Is the campus safe for students?",
      "Does SRM provide transport?",
    ],
  },
  fees: {
    label: "Fees & Scholarships",
    icon: "fa-rupee-sign",
    info: "SRMIST offers competitive fee structures across all programs with flexible payment options. B.Tech fees range from ₹1.8L to ₹2.5L per year depending on the specialization. The university provides merit-based scholarships of up to 100% tuition fee waiver for top performers, along with sports and need-based scholarships.",
    stats: [
      { value: "₹1.8L+", label: "B.Tech/yr" },
      { value: "100%", label: "Max Scholarship" },
      { value: "₹50Cr+", label: "Scholarship Fund" },
      { value: "30%+", label: "Students Avail" },
    ],
    hot: [
      "What is the fee for B.Tech CSE?",
      "Does SRM offer scholarships?",
      "How to apply for a scholarship?",
      "What is the hostel fee?",
      "Is there an installment option?",
      "What is the MBA fee structure?",
    ],
  },
  research: {
    label: "Research",
    icon: "fa-flask",
    info: "SRMIST is a research powerhouse with 920+ patents, 47,000+ publications, and 250+ Crores in externally funded projects. The university has state-of-the-art central research facilities including NRC, REACH, HPCC, and more. SRMIST ranks 2nd among private universities in the Nature Index and has top 2% scientists globally.",
    stats: [
      { value: "920+", label: "Patents" },
      { value: "47000+", label: "Publications" },
      { value: "250Cr+", label: "Research Funding" },
      { value: "2nd", label: "Nature Index" },
    ],
    hot: [
      "What research facilities are available?",
      "How to apply for PhD at SRM?",
      "What are the research focus areas?",
      "Does SRM have industry collaborations?",
      "How many patents has SRM filed?",
      "What is the research funding amount?",
    ],
  },
  international: {
    label: "International",
    icon: "fa-globe",
    info: "SRMIST has a strong global presence with 500+ international students from 85+ countries and 300+ MoUs with top foreign universities. Programs include Semester Abroad (SAP), Twinning/Transfer programs, and Global Immersion. SRMIST's International Advisory Board includes distinguished academicians from MIT, Carnegie Mellon, UC Davis, and more.",
    stats: [
      { value: "500+", label: "Intl Students" },
      { value: "85+", label: "Countries" },
      { value: "300+", label: "MoUs" },
      { value: "200+", label: "Students Abroad/yr" },
    ],
    hot: [
      "How can international students apply?",
      "What is the Semester Abroad Program?",
      "Which universities does SRM partner with?",
      "What is the twinning program?",
      "Are there scholarships for international students?",
      "What is the visa process for SRM?",
    ],
  },
};

let currentTopic = "general";

userInput.addEventListener("input", () => {
  userInput.style.height = "auto";
  userInput.style.height = Math.min(userInput.scrollHeight, 120) + "px";
});

userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

function getTime() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function addMessage(text, role, isDevMode = false) {
  const existing = chatWindow.querySelector(".welcome-block");
  if (existing) existing.remove();

  const msgDiv = document.createElement("div");
  msgDiv.className = `msg ${role}${isDevMode ? " dev-msg" : ""}`;

  const inner = document.createElement("div");
  inner.className = "msg-inner";

  if (role === "bot") {
    const avatar = document.createElement("div");
    avatar.className = "msg-avatar";
    avatar.innerHTML = '<img src="/static/logo.webp" alt="SRM" class="avatar-logo">';
    inner.appendChild(avatar);
  }

  const bubbleWrap = document.createElement("div");
  bubbleWrap.style.display = "flex";
  bubbleWrap.style.flexDirection = "column";

  if (isDevMode) {
    const badge = document.createElement("div");
    badge.className = "dev-badge";
    badge.textContent = "Dev mode — backend not connected";
    bubbleWrap.appendChild(badge);
  }

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  bubbleWrap.appendChild(bubble);
  inner.appendChild(bubbleWrap);

  const time = document.createElement("div");
  time.className = "msg-time";
  time.textContent = getTime();

  msgDiv.appendChild(inner);
  msgDiv.appendChild(time);
  chatWindow.appendChild(msgDiv);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function addTopicCard(topic) {
  const data = topicData[topic];
  if (!data) return;

  const existing = chatWindow.querySelector(".welcome-block");
  if (existing) existing.remove();

  const card = document.createElement("div");
  card.className = "msg bot";
  card.style.maxWidth = "100%";
  card.style.animation = "none";

  const inner = document.createElement("div");
  inner.className = "msg-inner";

  const avatar = document.createElement("div");
  avatar.className = "msg-avatar";
  avatar.innerHTML = '<img src="/static/logo.webp" alt="SRM" class="avatar-logo">';
  inner.appendChild(avatar);

  const wrap = document.createElement("div");
  wrap.style.display = "flex";
  wrap.style.flexDirection = "column";
  wrap.style.gap = "8px";

  const topicCard = document.createElement("div");
  topicCard.className = "topic-card";

  topicCard.innerHTML = `
    <div class="topic-card-header">
      <div class="topic-card-icon"><i class="fas ${data.icon}"></i></div>
      <div>
        <div class="topic-card-title">${data.label}</div>
        <div class="topic-card-subtitle">SRM Institute of Science and Technology</div>
      </div>
    </div>
    <p>${data.info}</p>
    <div class="topic-card-stats">
      ${data.stats.map(s => `
        <div class="topic-stat">
          <span class="topic-stat-value">${s.value}</span>
          <span class="topic-stat-label">${s.label}</span>
        </div>
      `).join("")}
    </div>
  `;
  wrap.appendChild(topicCard);

  const hotSection = document.createElement("div");
  hotSection.className = "hot-section";
  hotSection.innerHTML = `
    <div class="hot-header">
      <i class="fas fa-fire"></i>
      <span>Hot Queries</span>
    </div>
    <div class="hot-grid">
      ${data.hot.map(q => `
        <button class="chip" onclick="quickAsk('${q.replace(/'/g, "\\'")}')">${q}</button>
      `).join("")}
    </div>
  `;
  wrap.appendChild(hotSection);

  inner.appendChild(wrap);
  card.appendChild(inner);
  chatWindow.appendChild(card);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function showTyping() {
  const existing = chatWindow.querySelector("#typing-indicator");
  if (existing) existing.remove();

  const msgDiv = document.createElement("div");
  msgDiv.className = "msg bot";
  msgDiv.id = "typing-indicator";
  const inner = document.createElement("div");
  inner.className = "msg-inner";
  const avatar = document.createElement("div");
  avatar.className = "msg-avatar";
  avatar.innerHTML = '<img src="/static/logo.webp" alt="SRM" class="avatar-logo">';
  const bubble = document.createElement("div");
  bubble.className = "bubble typing-indicator";
  bubble.innerHTML = '<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>';
  inner.appendChild(avatar);
  inner.appendChild(bubble);
  msgDiv.appendChild(inner);
  chatWindow.appendChild(msgDiv);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function removeTyping() {
  const el = document.getElementById("typing-indicator");
  if (el) el.remove();
}

async function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  addMessage(text, "user");
  userInput.value = "";
  userInput.style.height = "auto";
  sendBtn.disabled = true;
  showTyping();

  const localAnswer = findAnswer(text);

  if (localAnswer) {
    await new Promise(r => setTimeout(r, 600 + Math.random() * 400));
    removeTyping();
    addMessage(localAnswer, "bot", false);
    setConnected(true);
    sendBtn.disabled = false;
    userInput.focus();
    return;
  }

  try {
    const res = await fetch(`${API_BASE_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text }),
    });
    const data = await res.json();
    removeTyping();
    if (data.reply) {
      addMessage(data.reply, "bot", data.dev_mode === true);
    } else if (data.error) {
      addMessage("Sorry, I don't have information on that yet. Try one of the hot queries above!", "bot");
    } else {
      addMessage("Something went wrong. Please try again.", "bot");
    }
    setConnected(true);
  } catch (err) {
    removeTyping();
    addMessage("Sorry, I don't have information on that yet. Try one of the hot queries above!", "bot");
    setConnected(false);
  }

  sendBtn.disabled = false;
  userInput.focus();
}

function quickAsk(text) {
  userInput.value = text;
  sendMessage();
}

function clearChat() {
  chatWindow.innerHTML = "";
  const data = topicData[currentTopic];
  if (data) addTopicCard(currentTopic);
}

function setTopic(topic) {
  document.querySelectorAll(".nav-item").forEach(el => el.classList.remove("active"));
  const btn = document.querySelector(`.nav-item[data-topic="${topic}"]`);
  if (btn) btn.classList.add("active");

  currentTopic = topic;
  const data = topicData[topic];
  const labelEl = document.getElementById("topic-label");
  if (data) {
    labelEl.innerHTML = `<i class="fas ${data.icon}"></i> ${data.label}`;
  }

  chatWindow.innerHTML = "";
  if (data) addTopicCard(topic);

  if (window.innerWidth < 768) toggleSidebar();
}

function toggleSidebar() {
  const sidebar = document.getElementById("sidebar");
  const overlay = document.getElementById("overlay");
  sidebar.classList.toggle("open");
  overlay.classList.toggle("show");
}

function setConnected(online) {
  connBadge.className = `conn-badge ${online ? "online" : "offline"}`;
  connText.textContent = online ? "Backend connected" : "Backend offline";
}

window.addEventListener("load", async () => {
  try {
    const res = await fetch(`${API_BASE_URL}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "ping" }),
    });
    const data = await res.json();
    const isDev = data.dev_mode === true;
    setConnected(!isDev);
    if (isDev) {
      connDot.style.background = "#fbbf24";
      connDot.style.animation = "pulse-dot 2s infinite";
      connBadge.className = "conn-badge";
      connText.textContent = "Dev mode (no RAG)";
    } else {
      connDot.style.background = "#4ade80";
      connDot.style.animation = "none";
    }
  } catch {
    setConnected(false);
  }

  addTopicCard("general");
});
