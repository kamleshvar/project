from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__)

# When your backend teammate runs the RAG server,
# set this to their machine's IP e.g. "http://192.168.1.10:8000"
RAG_BACKEND_URL = os.getenv("RAG_BACKEND_URL", None)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()

    if not user_message:
        return jsonify({"error": "Empty message"}), 400

    # If RAG backend is connected, forward the request
    if RAG_BACKEND_URL:
        import requests as req
        try:
            resp = req.post(f"{RAG_BACKEND_URL}/chat", json={"message": user_message}, timeout=15)
            return jsonify(resp.json())
        except Exception as e:
            return jsonify({"error": f"Backend unreachable: {str(e)}"}), 502

    # Dev mode: return a placeholder response
    return jsonify({
        "reply": f"[Dev mode] Backend not connected yet. Your question was: '{user_message}'\n\nConnect the RAG backend by setting RAG_BACKEND_URL in your .env file.",
        "dev_mode": True
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
